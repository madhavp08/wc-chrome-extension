const DEV_MODE = false;

const SUPABASE_CONFIG = {
  url: "https://luwpwlvbflaspmdqwahs.supabase.co",
  anonKey: "sb_publishable_nEpgvWy_9gSIZBtrKL3ISw_oUBCW9S_",
  table: "votes"
};

const APIFOOTBALL_CONFIG = {
  functionUrl: "https://luwpwlvbflaspmdqwahs.supabase.co/functions/v1/refwatch-events",
  finishedStatuses: ["AET", "PEN"]
};

const EVENT_TYPES = {
  vote: ["Card", "Var"],
  alert: ["Goal"]
};

const FAKE_VOTES = {
  min: 9,
  max: 108
};

const POLL = {
  options: ["Valid", "Invalid"],
  syncSeconds: 3,
  decisionSeconds: 20,
  confirmSeconds: 5,
  resultsDelaySeconds: 21,
  resultsThreshold: 0,
  momentShowSeconds: 5,
  countShowSeconds: 3,
  penaltyDecisionSeconds: 45,
  penaltyResultsSeconds: 8
};
